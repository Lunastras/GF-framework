using UnityEngine;

public class GfcCanvasRegister : GfcMutableSingletonRegister<GfcCanvas, Canvas, GfcGameState> { }