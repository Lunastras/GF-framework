using UnityEngine;

public class GfcCanvas : GfcMutableSingleton<Canvas, GfcGameState> { public static GfcCanvas Instance { get { return GetInstance<GfcCanvas>(); } } }