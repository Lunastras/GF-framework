using UnityEngine;

public class GfcCameraRegisterMulti : GfcMutableSingletonRegisterMulti<GfcCamera, Camera, GfcGameState> { }