using UnityEngine;

public class GfcCameraRegister : GfcMutableSingletonRegister<GfcCamera, Camera, GfcGameState> { }