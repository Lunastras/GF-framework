using UnityEngine;

public class GfcCamera : GfcMutableSingleton<Camera, GfcGameState> { public static GfcCamera Instance { get { return GetInstance<GfcCamera>(); } } }