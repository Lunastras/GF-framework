﻿#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InternalRealtimeCSG
{
	public static class CSGSceneManagerRedirector
	{
		public static CSGSceneManagerInterface Interface;
	}
}
#endif