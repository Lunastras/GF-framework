namespace RealtimeCSG.Foundation
{
    internal static class Versioning
    {
        public const string PluginVersion       = "1_601";
        public const string PluginDLLVersion    = "1_559";
    }
}
